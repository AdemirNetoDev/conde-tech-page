// @ts-nocheck
import { MapPin } from 'lucide-react'
import { NAV_LINKS, WHATSAPP_URL } from '@/lib/site/constants'

export default function Footer() {
  const year = new Date().getFullYear()

  const handleNav = (href) => {
    const el = document.querySelector(href)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <footer
      className="bg-[#0A0A0F] border-t border-[rgba(255,92,0,0.1)] pt-16 pb-8"
      role="contentinfo"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-[#FF5C00] flex items-center justify-center font-display text-white text-sm">
                CT
              </div>
              <span className="font-display text-xl text-white tracking-wider">
                CONDÉ <span className="text-[#FF5C00]">TECH</span>
              </span>
            </div>
            <p className="text-[#A0A0B0] text-sm leading-relaxed max-w-xs">
              Social Media que trabalha pelo seu negócio. Atendimento local, resultado profissional.
            </p>
            <div className="flex items-center gap-2 mt-4">
              <MapPin size={14} className="text-[#FF5C00]" aria-hidden="true" />
              <span className="text-[#A0A0B0] text-xs">Bom Jesus do Itabapoana/RJ e região</span>
            </div>
          </div>

          {/* Navigation */}
          <nav aria-label="Navegação do rodapé">
            <h3 className="text-white font-semibold text-sm mb-4 tracking-wide uppercase">
              Navegação
            </h3>
            <ul className="space-y-2" role="list">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => handleNav(link.href)}
                    className="text-[#A0A0B0] hover:text-[#FF5C00] text-sm transition-colors duration-200 cursor-pointer"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-4 tracking-wide uppercase">
              Contato
            </h3>
            <div className="space-y-3">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[#A0A0B0] hover:text-[#FF5C00] text-sm transition-colors duration-200 group"
                aria-label="Contato via WhatsApp"
              >
                <div className="w-8 h-8 rounded-full bg-[rgba(255,92,0,0.1)] flex items-center justify-center group-hover:bg-[rgba(255,92,0,0.2)] transition-colors">
                  <WhatsAppIcon />
                </div>
                WhatsApp
              </a>
              <a
                href="https://instagram.com/condetech"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[#A0A0B0] hover:text-[#FF5C00] text-sm transition-colors duration-200 group"
                aria-label="Instagram da Condé Tech"
              >
                <div className="w-8 h-8 rounded-full bg-[rgba(255,92,0,0.1)] flex items-center justify-center group-hover:bg-[rgba(255,92,0,0.2)] transition-colors">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FF5C00" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                </div>
                @condetech
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[rgba(255,255,255,0.05)] pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[#A0A0B0] text-xs">
            © {year} Condé Tech. Todos os direitos reservados.
          </p>
          <p className="text-[#A0A0B0] text-xs">
            Bom Jesus do Itabapoana · RJ · Brasil
          </p>
        </div>
      </div>
    </footer>
  )
}

function WhatsAppIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="#FF5C00" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}
